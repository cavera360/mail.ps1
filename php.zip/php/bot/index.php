<?php
die("<h1>Sem permissão para visualizar os documentos.</h1>");
?>